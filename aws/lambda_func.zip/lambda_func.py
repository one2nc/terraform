def lambda_handler(event, context):
    print("Hello World from AWS Lambda!")
    return "Hello World from AWS Lambda!"
